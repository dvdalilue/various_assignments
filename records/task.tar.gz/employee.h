#include "data.h"

#ifndef _check_telephone_
#define _check_telephone_

int check_telephone(char *telephone);

#endif

int add_new_employee(struct person *records, int n);
void print_all_employees();