#include "data.h"

#ifndef _check_telephone_
#define _check_telephone_

int check_telephone(char *telephone);

#endif

int add_new_student(struct person *records, int n);
void print_all_students();
void search_student_by_familyname(struct person *records, int n);