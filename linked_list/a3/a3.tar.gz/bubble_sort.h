

/* 
File name is bubble_sort.h

*/

#include "linked_list.h"

void bubbleSort(PersonalInfo **head);


